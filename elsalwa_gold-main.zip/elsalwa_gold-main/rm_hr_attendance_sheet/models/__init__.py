# -*- coding: utf-8 -*-

##############################################################################
#
#
#    Copyright (C) 2020-TODAY .
#    Author: Eng.Ramadan Khalil (<rkhalil1990@gmail.com>)
#
#    It is forbidden to publish, distribute, sublicense, or sell copies
#    of the Software or modified copies of the Software.
#
##############################################################################


from . import hr_attendance_sheet
from . import hr_attendance_policy
from . import hr_holidays
from . import hr_contract
from . import resource
from . import att_sheet_batch
from . import hr_payroll
from . import hr_employee
from . import hr_leave_type
from . import res_config_settings
